<?php

namespace App\Models\Backend;

use Illuminate\Database\Eloquent\Model;

class AdminModel extends Model
{
    //

    protected $table = 'admins';

    // khai báo khóa chính của bảng
    protected $primaryKey = 'id';


}
