<?php $__env->startSection('title', 'Danh sách đơn hàng'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Danh sách đơn hàng</h1>


    <div style="padding: 10px; border: 1px solid #4e73df; margin-bottom: 10px">
        <form name="search_orders" method="get" action="<?php echo e(htmlspecialchars($_SERVER["REQUEST_URI"])); ?>" class="form-inline">

            <input name="name" value="<?php echo e($searchKeyword); ?>" class="form-control" style="width: 350px; margin-right: 20px" placeholder="Nhập tên khách hàng bạn muốn tìm kiếm ..." autocomplete="off">


            <select name="sort" class="form-control" style="width: 150px; margin-right: 20px">
                <option value="">Sắp xếp</option>
                <option value="name_asc" <?php echo e($sort == "name_asc" ? " selected" : ""); ?>>Tên khách hàng tăng dần</option>
                <option value="name_desc" <?php echo e($sort == "name_desc" ? " selected" : ""); ?>>Tên khách hàng giảm dần</option>
            </select>

            <div style="padding: 10px 0">
                <input type="submit" name="search" class="btn btn-success" value="Lọc kết quả">
            </div>

            <div style="padding: 10px 0">
                <a href="#" id="clear-search" class="btn btn-warning">Clear filter</a>
            </div>

            <input type="hidden" name="page" value="1">

        </form>
    </div>

    <?php echo e($orders->links()); ?>


    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div style="padding: 20px">
        <a href="<?php echo e(url("/backend/orders/create")); ?>" class="btn btn-info">Thêm đơn hàng</a>
    </div>



    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
        <tr>
            <th>Id đơn hàng</th>
            <th>tên khách hàng</th>
            <th>số điện thoại</th>
            <th>email</th>
            <th>trạng thái</th>
            <td>tổng số sản phẩm</td>
            <td>tổng tiền</td>
            <th>hành động</th>
        </tr>
        </thead>
        <tfoot>
        <tr>
            <th>Id đơn hàng</th>
            <th>tên khách hàng</th>
            <th>số điện thoại</th>
            <th>email</th>
            <th>trạng thái</th>
            <td>tổng số sản phẩm</td>
            <td>tổng tiền</td>
            <th>hành động</th>
        </tr>
        </tfoot>
        <tbody>

        <?php if(isset($orders) && !empty($orders)): ?>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->id); ?></td>

                    <td><?php echo e($order->customer_name); ?></td>
                    <td><?php echo e($order->customer_phone); ?></td>
                    <td><?php echo e($order->customer_email); ?></td>

                    <td><?php echo e($order_status_defined[$order->order_status]); ?></td>

                    <td>
                        <?php echo e($order->total_product); ?>

                    </td>
                    <td><?php echo e($order->total_price); ?></td>

                    <td>
                        <a href="<?php echo e(url("/backend/orders/edit/$order->id")); ?>" class="btn btn-warning">Sửa đơn hàng</a>
                        <a href="<?php echo e(url("/backend/orders/delete/$order->id")); ?>" class="btn btn-danger">Xóa đơn hàng</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            Chưa có bản ghi nào trong bảng này
        <?php endif; ?>

        </tbody>
    </table>

    <?php echo e($orders->links()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('appendjs'); ?>

    <script type="text/javascript">

        $(document).ready(function () {
            $("#clear-search").on("click", function (e) {
                e.preventDefault();

                $("input[name='name']").val('');
                $("select[name='sort']").val('');

                $("form[name='search_orders']").trigger("submit");
            });

            $("a.page-link").on("click", function (e) {
                e.preventDefault();

                var rel = $(this).attr("rel");

                if (rel == "next") {
                    var page = $("body").find(".page-item.active > .page-link").eq(0).text();
                    console.log(" : " + page);
                    page = parseInt(page);
                    page += 1;
                } else if(rel == "prev") {
                    var page = $("body").find(".page-item.active > .page-link").eq(0).text();
                    console.log(page);
                    page = parseInt(page);
                    page -= 1;
                } else {
                    var page = $(this).text();
                }

                console.log(page);

                page = parseInt(page);

                $("input[name='page']").val(page);

                $("form[name='search_orders']").trigger("submit");
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7xcrud\resources\views/backend/orders/index.blade.php ENDPATH**/ ?>