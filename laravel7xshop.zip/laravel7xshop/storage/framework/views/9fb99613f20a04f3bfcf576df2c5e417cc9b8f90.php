<?php $__env->startSection('title', 'Cấu hình trang web'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Cấu hình trang web</h1>

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form name="settings" action="<?php echo e(url("/backend/settings/update")); ?>" method="post" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="site_name">Tên trang web:</label>
            <input type="text" name="site_name" class="form-control" id="site_name" value="<?php echo e(isset($settingConvert["site_name"]) ? $settingConvert["site_name"] : ""); ?>">
        </div>


        <div class="form-group">
            <label for="logo">Ảnh logo:</label>
            <input type="file" name="logo" class="form-control" id="logo">

            <?php if(isset($settingConvert["logo"]) && ($settingConvert["logo"])): ?>

                <?php
                $settingConvert["logo"] = str_replace("public/", "", $settingConvert["logo"]);
                ?>

                <div>
                    <img src="<?php echo e(asset("storage"."/".$settingConvert['logo'])); ?>" style="width: 200px; height: auto" />
                </div>

            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="meta_title">Meta title:</label>
            <input type="text" name="meta_title" class="form-control" id="meta_title" value="<?php echo e(isset($settingConvert["meta_title"]) ? $settingConvert["meta_title"] : ""); ?>">
        </div>

        <div class="form-group">
            <label for="meta_desc">Meta description:</label>
            <textarea name="meta_desc" class="form-control" rows="4" id="meta_desc"><?php echo e(isset($settingConvert["meta_desc"]) ? $settingConvert["meta_desc"] : ""); ?></textarea>
        </div>

        <div class="form-group">
            <label for="meta_keyword">Meta keyword:</label>
            <textarea name="meta_keyword" class="form-control" rows="4" id="meta_keyword"><?php echo e(isset($settingConvert["meta_keyword"]) ? $settingConvert["meta_keyword"] : ""); ?></textarea>
        </div>


        <button type="submit" class="btn btn-info">Lưu cấu hình</button>
    </form>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7xcrud\resources\views/backend/settings/edit.blade.php ENDPATH**/ ?>