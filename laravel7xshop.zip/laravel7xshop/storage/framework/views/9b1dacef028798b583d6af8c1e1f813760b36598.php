<?php $__env->startSection('title', 'Cập nhật admin'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Cập nhật admin</h1>

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form name="admin" action="<?php echo e(url("/backend/admins/update/$admin->id")); ?>" method="post" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="name">Tên:</label>
            <input type="text" name="name" class="form-control" id="name" value="<?php echo e($admin->name); ?>">
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" name="email" class="form-control" id="email" value="<?php echo e($admin->email); ?>">
        </div>

        <div class="form-group">
            <label for="image">Ảnh đại diện:</label>
            <input type="file" name="avatar" class="form-control" id="image">

            <?php if($admin->avatar): ?>

                <?php
                $admin->avatar = str_replace("public/", "", $admin->avatar);
                ?>

                <div>
                    <img src="<?php echo e(asset("storage/$admin->avatar")); ?>" style="width: 200px; height: auto" />
                </div>

            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="password">Mật khẩu mới:</label>
            <input type="text" name="password" class="form-control" id="password" value="">
        </div>

        <div class="form-group">
            <label for="password_confirmation">Nhập lại mật khẩu mới:</label>
            <input type="text" name="password_confirmation" class="form-control" id="password_confirmation" value="">
        </div>

        <div class="form-group">
            <label for="desc">Ghi chú:</label>
            <textarea name="desc" class="form-control" rows="5" id="desc"><?php echo e($admin->desc); ?></textarea>
        </div>


        <button type="submit" class="btn btn-info">Cập nhật thông tin admin</button>
    </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7xcrud\resources\views/backend/admins/edit.blade.php ENDPATH**/ ?>