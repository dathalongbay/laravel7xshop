<?php $__env->startSection('title', 'Cập nhật đơn hàng'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Cập nhật đơn hàng</h1>

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form name="orders" action="<?php echo e(url("/backend/orders/update/$order->id")); ?>" method="post" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="customer_name">Tên khách hàng:</label>
            <input type="text" name="customer_name" class="form-control" id="customer_name" value="<?php echo e($order->customer_name); ?>">
        </div>

        <div class="form-group">
            <label for="customer_email">Email:</label>
            <input type="text" name="customer_email" class="form-control" id="customer_email" value="<?php echo e($order->customer_email); ?>">
        </div>

        <div class="form-group">
            <label for="customer_phone">Số điện thoại:</label>
            <input type="text" name="customer_phone" class="form-control" id="customer_phone" value="<?php echo e($order->customer_phone); ?>">
        </div>


        <div class="form-group">
            <label for="order_status">Trạng thái đơn hàng:</label>
            <select name="order_status" class="form-control" style="width: 250px">
                <option value="1" <?php echo e($order->order_status == 1 ? "selected" : ""); ?>>Đang chờ xác nhận</option>
                <option value="2" <?php echo e($order->order_status == 2 ? "selected" : ""); ?>>Đã xác nhận</option>
                <option value="3" <?php echo e($order->order_status == 3 ? "selected" : ""); ?>>Đang vận chuyển</option>
                <option value="4" <?php echo e($order->order_status == 4 ? "selected" : ""); ?>>Hoàn tất</option>
                <option value="5" <?php echo e($order->order_status == 5 ? "selected" : ""); ?>>Đơn hủy</option>
                <option value="6" <?php echo e($order->order_status == 6 ? "selected" : ""); ?>>Đã hoàn tiền ( hủy đơn )</option>
            </select>
        </div>

        <div class="form-group">
            <label for="customer_address">Địa chỉ:</label>
            <textarea name="customer_address" class="form-control" rows="3" id="customer_address"><?php echo e($order->customer_address); ?></textarea>
        </div>

        <div class="form-group">
            <label for="customer_phone">Sản phẩm trong đơn hàng:</label>
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                <tr>
                    <th>Id sản phẩm</th>
                    <th>ảnh đại diện</th>
                    <th>tên sản phẩm</th>
                    <th>số lượng</th>
                    <th>giá tiền</th>
                    <th>tổng giá</th>
                </tr>
                </thead>
                <tbody id="list-cart-product">
                    <?php $__currentLoopData = $productInOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productInOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="tr-<?php echo e($productInOrder->id); ?>">
                            <td> <?php echo e($productInOrder->id); ?> </td>
                            <td>
                                <?php if($productInOrder->product_image): ?>
                                    <?php
                                    $productInOrder->product_image = str_replace("public/", "", $productInOrder->product_image);
                                    ?>

                                    <div>
                                        <img src="<?php echo e(asset("storage/$productInOrder->product_image")); ?>" style="width: 200px; height: auto" />
                                    </div>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e($productInOrder->product_name); ?></td>
                            <td>
                               <?php echo e($productInOrder->quantity); ?>

                            </td>
                            <td class="product_price">
                                <?php echo e($productInOrder->product_price); ?>

                            </td>
                            <td class="product_price_total">
                                <?php echo e($productInOrder->product_price * $productInOrder->quantity); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div style="font-weight: bold">Tổng tiền thanh toán: <strong id="payment-price"><?php echo e($order->total_price); ?></strong></div>
        </div>

        <div class="form-group">
            <label for="order_note">Ghi chú:</label>
            <textarea name="order_note" class="form-control" rows="3" id="order_note"><?php echo e($order->order_note); ?></textarea>
        </div>



        <button type="submit" class="btn btn-info">Cập nhật đơn hàng</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7xcrud\resources\views/backend/orders/edit.blade.php ENDPATH**/ ?>