<?php $__env->startSection('title', 'Xóa admin'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Xóa admin</h1>

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form name="admin" action="<?php echo e(url("/backend/admins/destroy/$admin->id")); ?>" method="post">

        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="product_name">ID admin:</label>
            <p><?php echo e($admin->id); ?></p>
        </div>

        <div class="form-group">
            <label for="product_name">Tên admin:</label>
            <p><?php echo e($admin->name); ?></p>
        </div>

        <div class="form-group">
            <label for="product_name">Email admin:</label>
            <p><?php echo e($admin->email); ?></p>
        </div>

        <button type="submit" class="btn btn-danger">Xác nhận xóa!</button>
    </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7xcrud\resources\views/backend/admins/delete.blade.php ENDPATH**/ ?>