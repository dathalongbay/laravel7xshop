<?php $__env->startSection('title', 'Trang chi tiết sản phẩm'); ?>

<?php $__env->startSection('content'); ?>

<!-- Hero Section Begin -->
<section class="hero hero-normal">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="hero__categories">
                    <div class="hero__categories__all">
                        <i class="fa fa-bars"></i>
                        <span>Danh mục sản phẩm</span>
                    </div>
                    <ul style="display: none">
                        <?php if($categories): ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url("/category/$category->id")); ?>"><?php echo e($category->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-9">
                <div class="hero__search">
                    <div class="hero__search__form">
                        <form name="search" method="get" action="<?php echo e(url("/search")); ?>">
                            <input type="text" name="keyword" placeholder="Bạn muốn tìm gì ?">
                            <button type="submit" class="site-btn">TÌM KIẾM</button>
                        </form>
                    </div>
                    <div class="hero__search__phone">
                        <div class="hero__search__phone__icon">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="hero__search__phone__text">
                            <h5>+65 11.188.888</h5>
                            <span>Hỗ trợ 24/7 time</span>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<!-- Hero Section End -->

<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-section set-bg" style="background: #7fad39">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2><?php echo e($product->product_name); ?></h2>
                    <div class="breadcrumb__option">
                        <a href="<?php echo e(url("/")); ?>">Trang chủ</a>
                        <a href="<?php echo e(url("/category/$product->category->id")); ?>"><?php echo e($product->category->name); ?></a>
                        <span><?php echo e($product->product_name); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->

<!-- Product Details Section Begin -->
<section class="product-details spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="product__details__pic">
                    <div class="product__details__pic__item">
                        <?php
                        $product->product_image = str_replace("public/", "", $product->product_image);
                        ?>
                        <img class="product__details__pic__item--large"
                             src="<?php echo e(asset("storage/$product->product_image")); ?>" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="product__details__text">
                    <h3><?php echo e($product->product_name); ?></h3>

                    <div class="product__details__price">$<?php echo e($product->product_price); ?></div>
                    <p><?php echo $product->product_desc; ?></p>
                    <div class="product__details__quantity">
                        <div class="quantity">
                            <div class="pro-qty">
                                <input name="quantity" type="text" value="1">
                            </div>
                        </div>
                    </div>
                    <a href="#" id="addtocart" data-id="<?php echo e($product->id); ?>" class="primary-btn">THÊM VÀO GIỎ HÀNG</a>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="product__details__tab">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab"
                               aria-selected="true">Description</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="tabs-1" role="tabpanel">
                            <div class="product__details__tab__desc">
                                <h6>Products Infomation</h6>
                                <p><?php echo $product->product_desc; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Product Details Section End -->

<div id="aftercart" class="modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Thông báo giỏ hàng</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Thêm sản phẩm vào giỏ hàng thành công! Vui lòng
                chọn hành động để tiếp tục</p>

                <a href="<?php echo e(url("/cart")); ?>" class="btn btn-success">Đến trang giỏ hàng</a>

                <a href="<?php echo e(url("/payment")); ?>" class="btn btn-info">Đến trang thanh toán</a>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tiếp tục mua sắm</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("appentjs"); ?>
<script>

    $(document).ready(function () {

        $("#addtocart").on("click", function (e) {
            e.preventDefault();

            var id = $(this).data("id");
            id = parseInt(id);

            var quantity = $("input[name='quantity']").val();
            quantity = parseInt(quantity);


            if (id > 0) {
                $.ajax({
                    method: "POST",
                    url: "<?php echo e(url('/cart/add')); ?>",
                    data: { id: id,quantity: quantity,_token: "<?php echo e(csrf_token()); ?>" }
                }).done(function( product ) {

                    $('#aftercart').modal();
                });
            } else {
                alert("có lỗi hệ thống vui lòng liên hệ admin");
            }
            console.log(id);
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.book2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7xcrud\resources\views/site/product.blade.php ENDPATH**/ ?>