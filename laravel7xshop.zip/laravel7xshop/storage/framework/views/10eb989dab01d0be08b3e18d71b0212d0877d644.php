<?php $__env->startSection('title', 'Danh sách danh mục'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Danh sách danh mục</h1>


    <div style="padding: 10px; border: 1px solid #4e73df; margin-bottom: 10px">
        <form name="search_category" method="get" action="<?php echo e(htmlspecialchars($_SERVER["REQUEST_URI"])); ?>" class="form-inline">

            <input name="name" value="<?php echo e($searchKeyword); ?>" class="form-control" style="width: 350px; margin-right: 20px" placeholder="Nhập tên danh mục bạn muốn tìm kiếm ..." autocomplete="off">


            <select name="sort" class="form-control" style="width: 150px; margin-right: 20px">
                <option value="">Sắp xếp</option>
                <option value="name_asc" <?php echo e($sort == "name_asc" ? " selected" : ""); ?>>Tên tăng dần</option>
                <option value="name_desc" <?php echo e($sort == "name_desc" ? " selected" : ""); ?>>Tên giảm dần</option>
            </select>

            <div style="padding: 10px 0">
                <input type="submit" name="search" class="btn btn-success" value="Lọc kết quả">
            </div>

            <div style="padding: 10px 0">
                <a href="#" id="clear-search" class="btn btn-warning">Clear filter</a>
            </div>

            <input type="hidden" name="page" value="1">

        </form>
    </div>

    <?php echo e($categories->links()); ?>


    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div style="padding: 20px">
        <a href="<?php echo e(url("/backend/category/create")); ?>" class="btn btn-info">Thêm danh mục</a>
    </div>



    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
        <tr>
            <th>Id danh mục</th>
            <th>ảnh đại diện</th>
            <th>tên danh mục</th>
            <th>hành động</th>
        </tr>
        </thead>
        <tfoot>
        <tr>
            <th>Id danh mục</th>
            <th>ảnh đại diện</th>
            <th>tên danh mục</th>
            <th>hành động</th>
        </tr>
        </tfoot>
        <tbody>

        <?php if(isset($categories) && !empty($categories)): ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($category->id); ?></td>
                    <td>
                        <?php if($category->image): ?>
                            <?php
                            $category->image = str_replace("public/", "", $category->image);
                            ?>

                            <div>
                                <img src="<?php echo e(asset("storage/$category->image")); ?>" style="width: 200px; height: auto" />
                            </div>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e($category->name); ?></td>

                    <td>
                        <a href="<?php echo e(url("/backend/category/edit/$category->id")); ?>" class="btn btn-warning">Sửa danh mục</a>
                        <a href="<?php echo e(url("/backend/category/delete/$category->id")); ?>" class="btn btn-danger">Xóa danh mục</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            Chưa có bản ghi nào trong bảng này
        <?php endif; ?>

        </tbody>
    </table>

    <?php echo e($categories->links()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('appendjs'); ?>

    <script type="text/javascript">

        $(document).ready(function () {
            $("#clear-search").on("click", function (e) {
                e.preventDefault();

                $("input[name='name']").val('');
                $("select[name='sort']").val('');

                $("form[name='search_category']").trigger("submit");
            });

            $("a.page-link").on("click", function (e) {
                e.preventDefault();

                var rel = $(this).attr("rel");

                if (rel == "next") {
                    var page = $("body").find(".page-item.active > .page-link").eq(0).text();
                    console.log(" : " + page);
                    page = parseInt(page);
                    page += 1;
                } else if(rel == "prev") {
                    var page = $("body").find(".page-item.active > .page-link").eq(0).text();
                    console.log(page);
                    page = parseInt(page);
                    page -= 1;
                } else {
                    var page = $(this).text();
                }

                console.log(page);

                page = parseInt(page);

                $("input[name='page']").val(page);

                $("form[name='search_category']").trigger("submit");
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7xcrud\resources\views/backend/category/index.blade.php ENDPATH**/ ?>