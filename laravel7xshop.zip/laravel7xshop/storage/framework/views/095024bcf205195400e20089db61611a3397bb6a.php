<?php $__env->startSection('title', 'Xóa danh mục'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Xóa danh mục</h1>

    <form name="product" action="<?php echo e(url("/backend/category/destroy/$category->id")); ?>" method="post">

        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="product_name">ID danh mục:</label>
            <p><?php echo e($category->id); ?></p>
        </div>

        <div class="form-group">
            <label for="product_name">Tên danh mục:</label>
            <p><?php echo e($category->name); ?></p>
        </div>

        <button type="submit" class="btn btn-danger">Xác nhận xóa danh mục</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7xcrud\resources\views/backend/category/delete.blade.php ENDPATH**/ ?>