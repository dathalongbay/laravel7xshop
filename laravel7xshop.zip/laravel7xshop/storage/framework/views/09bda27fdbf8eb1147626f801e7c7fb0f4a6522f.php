<?php $__env->startSection('title', 'Sửa danh mục'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Sửa danh mục</h1>

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form name="category" action="<?php echo e(url("/backend/category/update/$category->id")); ?>" method="post" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="name">Tên danh mục:</label>
            <input type="text" name="name" class="form-control" id="name" value="<?php echo e($category->name); ?>">
        </div>

        <div class="form-group">
            <label for="slug">Slug danh mục:</label>
            <input type="text" name="slug" class="form-control" id="slug" value="<?php echo e($category->slug); ?>">
        </div>

        <div class="form-group">
            <label for="image">Ảnh danh mục:</label>
            <input type="file" name="image" class="form-control" id="image">

            <?php if($category->image): ?>

                <?php
                $category->image = str_replace("public/", "", $category->image);
                ?>

                <div>
                    <img src="<?php echo e(asset("storage/$category->image")); ?>" style="width: 200px; height: auto" />
                </div>

            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="desc">Mô tả danh mục:</label>
            <textarea name="desc" class="form-control" rows="10" id="desc"><?php echo e($category->desc); ?></textarea>
        </div>

        <button type="submit" class="btn btn-info">Cập nhật danh mục</button>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('appendjs'); ?>

    <script src="<?php echo e(asset("/be-assets/js/tinymce/tinymce.min.js")); ?>"></script>
    <script>
        tinymce.init({
            selector: '#desc'
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7xcrud\resources\views/backend/category/edit.blade.php ENDPATH**/ ?>