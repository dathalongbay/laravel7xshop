<?php $__env->startSection('title', 'Trang giỏ hàng'); ?>

<?php $__env->startSection('content'); ?>

<!-- Hero Section Begin -->
<section class="hero hero-normal">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="hero__categories">
                    <div class="hero__categories__all">
                        <i class="fa fa-bars"></i>
                        <span>Danh mục sản phẩm</span>
                    </div>
                    <ul style="display: none">
                        <?php if($categories): ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url("/category/$category->id")); ?>"><?php echo e($category->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-9">
                <div class="hero__search">
                    <div class="hero__search__form">
                        <form name="search" method="get" action="<?php echo e(url("/search")); ?>">
                            <input type="text" name="keyword" placeholder="Bạn muốn tìm gì ?">
                            <button type="submit" class="site-btn">TÌM KIẾM</button>
                        </form>
                    </div>
                    <div class="hero__search__phone">
                        <div class="hero__search__phone__icon">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="hero__search__phone__text">
                            <h5>+65 11.188.888</h5>
                            <span>Hỗ trợ 24/7 time</span>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<!-- Hero Section End -->

<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-section set-bg" style="background: #7fad39">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>Shopping Cart</h2>
                    <div class="breadcrumb__option">
                        <a href="<?php echo e(url("/")); ?>">Home</a>
                        <span>Shopping Cart</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->
<?php
$total = 0;
?>
<!-- Shoping Cart Section Begin -->
<section class="shoping-cart spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="shoping__cart__table">
                    <table>
                        <thead>
                        <tr>
                            <th class="shoping__product">Products</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php if($products): ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $product->product_image = str_replace("public/", "", $product->product_image);
                                ?>
                                <tr>
                                    <td class="shoping__cart__item">
                                        <img src="<?php echo e(asset("storage/$product->product_image")); ?>" style="width: 150px" alt="">
                                        <h5><?php echo e($product->product_name); ?></h5>
                                    </td>
                                    <td class="shoping__cart__price">
                                        $<?php echo e($product->product_price); ?>

                                    </td>
                                    <td class="shoping__cart__quantity">
                                        <div class="quantity">
                                            <div class="pro-qty">
                                                <input type="text" name="qttCart[]" class="qttCart" data-id="<?php echo e($product->id); ?>" value="<?php echo e($cart[$product->id][0]['quantity']); ?>">
                                            </div>
                                        </div>
                                    </td>
                                    <td class="shoping__cart__total">
                                        $<?php echo e($cart[$product->id][0]['quantity'] * $product->product_price); ?>

                                        <?php
                                            $total += $cart[$product->id][0]['quantity'] * $product->product_price;
                                        ?>
                                    </td>
                                    <td class="shoping__cart__item__close">
                                        <span class="icon_close removeCart" data-id="<?php echo e($product->id); ?>"></span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="shoping__cart__btns">
                    <a href="<?php echo e(url("/")); ?>" class="primary-btn cart-btn">CONTINUE SHOPPING</a>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="shoping__checkout">
                    <h5>Cart Total</h5>
                    <ul>
                        <li>Subtotal <span>$ <?php echo e($total); ?></span></li>
                        <li>Total <span>$<?php echo e($total); ?></span></li>
                    </ul>
                    <a href="<?php echo e(url("/payment")); ?>" class="primary-btn">PROCEED TO CHECKOUT</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Shoping Cart Section End -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection("appentjs"); ?>
    <script>

        $(document).ready(function () {


            $("body").on("click", ".qtybtn", function (e) {

                var input = $(this).closest(".pro-qty").find("input").eq(0);
                var id = input.data("id");
                id = parseInt(id);

                var qtt = input.val();
                qtt = parseInt(qtt);

                if (id > 0 && qtt > 0) {
                    $.ajax({
                        method: "POST",
                        url: "<?php echo e(url('/cart/update')); ?>",
                        data: { id: id,quantity: qtt,_token: "<?php echo e(csrf_token()); ?>" }
                    }).done(function( product ) {

                        location.reload();
                    });
                } else {
                    alert("có lỗi hệ thống vui lòng liên hệ admin");
                }
            });


            $(".qttCart").on("change", function (e) {

                alert(111);

                var id = $(this).data("id");
                id = parseInt(id);

                var qtt = $(this).val();
                qtt = parseInt(qtt);

                if (id > 0 && qtt > 0) {
                    $.ajax({
                        method: "POST",
                        url: "<?php echo e(url('/cart/update')); ?>",
                        data: { id: id,quantity: qtt,_token: "<?php echo e(csrf_token()); ?>" }
                    }).done(function( product ) {

                        location.reload();
                    });
                } else {
                    alert("có lỗi hệ thống vui lòng liên hệ admin");
                }
                console.log(id);
            });

            $(".removeCart").on("click", function (e) {
                e.preventDefault();

                var id = $(this).data("id");
                id = parseInt(id);

                if (id > 0) {
                    $.ajax({
                        method: "POST",
                        url: "<?php echo e(url('/cart/remove')); ?>",
                        data: { id: id,_token: "<?php echo e(csrf_token()); ?>" }
                    }).done(function( product ) {

                        location.reload();
                    });
                } else {
                    alert("có lỗi hệ thống vui lòng liên hệ admin");
                }
                console.log(id);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.book2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7xcrud\resources\views/site/cart.blade.php ENDPATH**/ ?>