<?php $__env->startSection('title', 'Xóa sản phẩm'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Xóa sản phẩm</h1>

    <form name="product" action="<?php echo e(url("/backend/product/destroy/$product->id")); ?>" method="post">

        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="product_name">ID sản phẩm:</label>
            <p><?php echo e($product->id); ?></p>
        </div>

        <div class="form-group">
            <label for="product_name">Tên sản phẩm:</label>
            <p><?php echo e($product->product_name); ?></p>
        </div>

        <button type="submit" class="btn btn-danger">Xác nhận xóa sản phẩm</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7xcrud\resources\views/backend/products/delete.blade.php ENDPATH**/ ?>