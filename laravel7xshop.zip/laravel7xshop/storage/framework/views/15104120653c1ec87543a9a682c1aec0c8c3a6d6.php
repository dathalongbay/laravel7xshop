<?php $__env->startSection('title', 'Liệt kê admin'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Liệt kê admin</h1>

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div style="padding: 10px; border: 1px solid #4e73df; margin-bottom: 10px">
        <form name="search_admin" method="get" action="<?php echo e(htmlspecialchars($_SERVER["REQUEST_URI"])); ?>" class="form-inline">

            <input name="name" value="<?php echo e($searchKeyword); ?>" class="form-control" style="width: 350px; margin-right: 20px" placeholder="Nhập tên quản trị viên bạn muốn tìm kiếm ..." autocomplete="off">


            <select name="sort" class="form-control" style="width: 150px; margin-right: 20px">
                <option value="">Sắp xếp</option>
                <option value="name_asc" <?php echo e($sort == "name_asc" ? " selected" : ""); ?>>Tên tăng dần</option>
                <option value="name_desc" <?php echo e($sort == "name_desc" ? " selected" : ""); ?>>Tên giảm dần</option>
            </select>

            <div style="padding: 10px 0">
                <input type="submit" name="search" class="btn btn-success" value="Lọc kết quả">
            </div>

            <div style="padding: 10px 0">
                <a href="#" id="clear-search" class="btn btn-warning">Clear filter</a>
            </div>

            <input type="hidden" name="page" value="1">

        </form>
    </div>

    <?php echo e($admins->links()); ?>


    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div style="padding: 20px">
        <a href="<?php echo e(url("/backend/admins/create")); ?>" class="btn btn-info">Thêm quản trị viên</a>
    </div>

    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
        <tr>
            <th>Id</th>
            <th>ảnh đại diện</th>
            <th>tên</th>
            <th>email</th>
            <th>hành động</th>
        </tr>
        </thead>
        <tfoot>
        <tr>
            <th>Id</th>
            <th>ảnh đại diện</th>
            <th>tên</th>
            <th>email</th>
            <th>hành động</th>
        </tr>
        </tfoot>
        <tbody>

        <?php if(isset($admins) && !empty($admins)): ?>
            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($admin->id); ?></td>
                    <td>
                        <?php if($admin->avatar): ?>
                            <?php
                            $admin->avatar = str_replace("public/", "", $admin->avatar);
                            ?>

                            <div>
                                <img src="<?php echo e(asset("storage/$admin->avatar")); ?>" style="width: 200px; height: auto" />
                            </div>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e($admin->name); ?></td>
                    <td><?php echo e($admin->email); ?></td>

                    <td>
                        <a href="<?php echo e(url("/backend/admins/edit/$admin->id")); ?>" class="btn btn-warning">Sửa quản trị viên</a>
                        <a href="<?php echo e(url("/backend/admins/delete/$admin->id")); ?>" class="btn btn-danger">Xóa quản trị viên</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            Chưa có bản ghi nào trong bảng này
        <?php endif; ?>

        </tbody>
    </table>

    <?php echo e($admins->links()); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('appendjs'); ?>

    <script type="text/javascript">

        $(document).ready(function () {
            $("#clear-search").on("click", function (e) {
                e.preventDefault();

                $("input[name='name']").val('');
                $("select[name='sort']").val('');

                $("form[name='search_admin']").trigger("submit");
            });

            $("a.page-link").on("click", function (e) {
                e.preventDefault();

                var rel = $(this).attr("rel");

                if (rel == "next") {
                    var page = $("body").find(".page-item.active > .page-link").eq(0).text();
                    console.log(" : " + page);
                    page = parseInt(page);
                    page += 1;
                } else if(rel == "prev") {
                    var page = $("body").find(".page-item.active > .page-link").eq(0).text();
                    console.log(page);
                    page = parseInt(page);
                    page -= 1;
                } else {
                    var page = $(this).text();
                }

                console.log(page);

                page = parseInt(page);

                $("input[name='page']").val(page);

                $("form[name='search_admin']").trigger("submit");
            });
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7xcrud\resources\views/backend/admins/index.blade.php ENDPATH**/ ?>