<?php $__env->startSection('title', 'Xóa đơn hàng'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Xóa đơn hàng</h1>

    <form name="product" action="<?php echo e(url("/backend/orders/destroy/$order->id")); ?>" method="post">

        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="product_name">ID đơn hàng:</label>
            <p><?php echo e($order->id); ?></p>
        </div>

        <div class="form-group">
            <label for="product_name">Tên khách hàng:</label>
            <p><?php echo e($order->customer_name); ?></p>
        </div>

        <button type="submit" class="btn btn-danger">Xác nhận xóa đơn hàng</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7xcrud\resources\views/backend/orders/delete.blade.php ENDPATH**/ ?>