<!-- Header Section Begin -->
<header class="header">
    <div class="header__top">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="header__top__left">
                        <ul>
                            <li><i class="fa fa-envelope"></i> shop@book.com</li>
                            <li>Miễn phí giao hàng cho đơn từ 99.000 VND</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="header__top__right">
                        <div class="header__top__right__social">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-linkedin"></i></a>
                            <a href="#"><i class="fa fa-pinterest-p"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-9">
                <div class="header__logo">
                    <?php
                    $logo = str_replace("public/", "", $config['logo']);
                    ?>


                    <a href="<?php echo e(url("/")); ?>"><img src="<?php echo e(asset("storage/$logo")); ?>" alt=""></a>

                </div>
            </div>
            <div class="col-lg-3">
                <div class="header__cart">
                    <ul>
                        <li><a href="<?php echo e(url("/cart")); ?>"><i class="fa fa-shopping-bag"></i> <span><?php echo e($totalQttCart); ?></span></a></li>
                    </ul>
                    <div class="header__cart__price">tổng: <span>$ <?php echo e($totalPriceCart); ?></span></div>
                </div>
            </div>
        </div>
        <div class="humberger__open">
            <i class="fa fa-bars"></i>
        </div>
    </div>
</header>
<!-- Header Section End -->
<?php /**PATH C:\xampp\htdocs\laravel7xcrud\resources\views/site/partials/header2.blade.php ENDPATH**/ ?>